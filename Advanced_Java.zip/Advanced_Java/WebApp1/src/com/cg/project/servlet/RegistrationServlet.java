package com.cg.project.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.bean.Associate;

@WebServlet("/registration")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public RegistrationServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		String department = request.getParameter("department");
		String designation = request.getParameter("designation");
		String dob = request.getParameter("dob");
		int associateId = Integer.parseInt(request.getParameter("associateId"));
		String password = request.getParameter("password");
		String email = request.getParameter("email");
		int age = Integer.parseInt(request.getParameter("age"));
		String[] hobbies = request.getParameterValues("hobbies");

		Associate associate = new Associate(associateId, age, firstName,
				lastName, department, designation, dob, password, email,
				hobbies);

		RequestDispatcher dispatcher;

		dispatcher = request.getRequestDispatcher("registrationSuccess.jsp");
		request.setAttribute("associate", associate);
		dispatcher.forward(request, response);

		/*
		 * PrintWriter out = response.getWriter(); DateFormat dateFormat = new
		 * SimpleDateFormat("mm-dd-yyyy"); Date date; try { date =
		 * dateFormat.parse(dob);
		 * out.println("<html><body><div align = 'center'>");
		 * out.println("<table>"); out.println("<tr><td>Firstname</td><td>" +
		 * firstName + "</td></tr>"); out.println("<tr><td>Lastname</td><td>" +
		 * lastName + "</td></tr>"); out.println("<tr><td>Department</td><td>" +
		 * dept + "</td></tr>"); out.println("<tr><td>Designation</td><td>" +
		 * designation + "</td></tr>"); out.println("<tr><td>Dob</td><td>" +
		 * date + "</td></tr>"); out.println("<tr><td>AssociateId</td><td>" +
		 * associateId + "</td></tr>"); out.println("<tr><td>Password</td><td>"
		 * + password + "</td></tr>"); out.println("<tr><td>Hobbies:</td><td>");
		 * for (String str : hobbies) out.print(str+" ");
		 * out.print("</td></tr>"); out.println("<tr><td>Email: </td><td>" +
		 * email + "</td></tr>"); out.println("<tr><td>Age: </td><td>" + dob +
		 * "</td></tr>"); out.println("</table>");
		 * out.print("</div></body></html>"); } catch (ParseException e) { //
		 * TODO Auto-generated catch block e.printStackTrace(); }
		 */

	}

}
