package com.cg.project.servlet;

import java.io.IOException;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.bean.Associate;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public LoginServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int associateId = Integer.parseInt(request.getParameter("associateId"));
		String password = request.getParameter("password");
		
		Associate associate = new Associate(associateId, password);
		
		RequestDispatcher dispatcher;
		if(associate.getAssociateId()==12345 && associate.getPassword().equals("asdf")){
			dispatcher = request.getRequestDispatcher("loginSuccessPage.jsp");
			request.setAttribute("associate", associate);
			dispatcher.forward(request, response);
		}
		else{
			
			dispatcher = request.getRequestDispatcher("loginPage.jsp");
			request.setAttribute("errorMessage","AssociateId or Password incorrect");
			dispatcher.forward(request, response);
		}
		/*PrintWriter out = response.getWriter();
		out.println("<html><body><div align = 'center'>");
		if(associateId.equals("12345") && password.equals("asdf"))
			out.println("<font color='green'>Welcome Associate "+associateId+"</font>");
		else
			out.println("<font color='red'>Associate ID or Password entered is incorrect</font>");
		out.print("</div></body></html>");*/
		
		
	}

}
